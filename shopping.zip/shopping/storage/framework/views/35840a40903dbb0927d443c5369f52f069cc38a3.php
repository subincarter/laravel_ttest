<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
</head>

<body>
    <form action="" method="">
        <button  style="float: right;"><a href="<?php echo e(url('products')); ?>" class=""> goto product</a></button>
    <?php echo csrf_field(); ?>
        <table>
            <thead>
                <th>Product Name</th>
                <th>Product Price</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($d['products']['productname']); ?></td>
                    <td><?php echo e($d['price']); ?></td>
                    <td><a href="<?php echo e(url('removeProduct',$d['id'])); ?>" class="btn btn-primary">remove</a></td>
                    <td><a href="<?php echo e(url('buyProduct',$d['id'])); ?>" class="btn btn-primary">Buy</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>


    </form>

</body>

</html><?php /**PATH G:\Laravel Projects\shopping\resources\views/order.blade.php ENDPATH**/ ?>